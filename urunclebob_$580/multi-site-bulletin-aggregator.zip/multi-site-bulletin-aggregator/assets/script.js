document.addEventListener("DOMContentLoaded", function () {

    fetch(msb_ajax.url + "?action=msb_get_posts")
        .then(res => res.json())
        .then(posts => {

            const titles = document.querySelectorAll(".news_title");
            const links  = document.querySelectorAll(".news_link");
            const times  = document.querySelectorAll(".news_time");

            posts.forEach((post, index) => {

                if (titles[index]) {
                    titles[index].innerHTML = post.title;
                }

                if (links[index]) {
                    links[index].setAttribute("href", post.link);
                }

                if (times[index]) {
                    times[index].innerHTML = timeAgo(post.time);
                }

            });

        });

    // optional time ago function
    function timeAgo(datetime) {
        const seconds = Math.floor((new Date() - new Date(datetime)) / 1000);

        const units = {
            year: 31536000,
            month: 2592000,
            day: 86400,
            hour: 3600,
            minute: 60
        };

        for (let key in units) {
            let val = Math.floor(seconds / units[key]);
            if (val >= 1) return val + key[0].toUpperCase() + " AGO";
        }

        return "JUST NOW";
    }

});